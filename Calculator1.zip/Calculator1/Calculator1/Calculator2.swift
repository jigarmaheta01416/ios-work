

import Foundation
class Calculator2{
var values = [String]()
func push(s: String){
values.append(s)
print(values)
}
func calc() -> Int {
var n1 = 0
var n2 = 0
var calResult = 0
for stringIndex in 0...(values.count-1)
{
if( values[stringIndex] == "+" ){
if n1 == 0 && n2 == 0{
    n1 = Int(values[stringIndex-1])!
    n2 = Int(values[stringIndex+1])!
calResult = n1 + n2
    n1 = calResult
}
else
{
    n2 = Int(values[stringIndex+1])!
calResult = n1 + n2
    n1 = calResult
}
}
if( values[stringIndex] == "-" ){
if n1 == 0 && n2 == 0{
    n1 = Int(values[stringIndex-1])!
    n2 = Int(values[stringIndex+1])!
calResult = n1 - n2
    n1 = calResult
}
else
{
    n2 = Int(values[stringIndex+1])!
calResult = n1 - n2
    n1 = calResult
}
}
    if( values[stringIndex] == "*" ){
    if n1 == 0 && n2 == 0{
        n1 = Int(values[stringIndex-1])!
        n2 = Int(values[stringIndex+1])!
    calResult = n1 * n2
        n1 = calResult
    }
    else
    {
        n2 = Int(values[stringIndex+1])!
    calResult = n1 * n2
        n1 = calResult
    }
    }
    if( values[stringIndex] == "/" ){
    if n1 == 0 && n2 == 0{
        n1 = Int(values[stringIndex-1])!
        n2 = Int(values[stringIndex+1])!
    calResult = n1 / n2
        n1 = calResult
    }
    else
    {
        n2 = Int(values[stringIndex+1])!
    calResult = n1 / n2
        n1 = calResult
    }
    }
    }
    values.removeAll()
    return calResult
    }
    func checkValues() -> Bool
    {
        var operatorIndex = 1
    var numIndex = 0
    if values[0] == "+" && values[0] == "-" && values[0] == "*" && values[0] == "/" {
    values.removeAll()
    return false }
    for index in 1...(values.count-1){
    if( values[index] == "+" ){
    if operatorIndex == index-1 || operatorIndex == index+1 { values.removeAll()
    return false
    }
    else
    {
    operatorIndex = index
        continue
    }}
    if( values[index] == "-" ){
    if operatorIndex == index-1 || operatorIndex == index+1 { values.removeAll()
    return false
    }
    else
    {
    operatorIndex = index
    continue }
    }
    if( values[index] == "*" ){
    if operatorIndex == index-1 || operatorIndex == index+1 { values.removeAll()
    return false
    }
    else
    {
    operatorIndex = index
    continue }
    }
    if( values[index] == "/" ){
    if operatorIndex == index-1 || operatorIndex == index+1 { values.removeAll()
    return false
    }

    else
    {
    operatorIndex = index
    continue }
    }
    if( values[index] == "=" ){
        return false
    }
    else{
        if numIndex == index-1 || numIndex == index+1{
        values.removeAll()
    return false
    }
    else
        {
    numIndex = index
            
        continue
            
    }
    }
        
    }
    return true
}
    func clean() {
        
    values.removeAll()
        
    }
 
}
